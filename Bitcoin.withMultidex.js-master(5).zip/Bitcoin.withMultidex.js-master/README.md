# Bitcoin.withMultidex.js
Hive class miner for Bitcoin with MultiDex js formatted and integrated as an application.
